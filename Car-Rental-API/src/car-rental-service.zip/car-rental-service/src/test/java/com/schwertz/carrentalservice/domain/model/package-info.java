
/**
 * Contains test cases of business domain model.
 */
package com.schwertz.carrentalservice.domain.model;
