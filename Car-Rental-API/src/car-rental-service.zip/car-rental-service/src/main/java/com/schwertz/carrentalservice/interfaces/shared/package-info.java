
/**
 * Contains utilities that helps in communication between client and provided
 * interfaces and is shared across all interfaces provide by this application.
 */
package com.schwertz.carrentalservice.interfaces.shared;
