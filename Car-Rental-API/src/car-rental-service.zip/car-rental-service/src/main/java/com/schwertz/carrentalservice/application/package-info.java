
/**
 * Contains services that application provides. A service typically mean a use case.
 */
package com.schwertz.carrentalservice.application;
