
/**
 * Contains configuration level utilities that helps configuring service.
 */
package com.schwertz.carrentalservice.utils;
