
/**
 * Contains utilities that helps in operation REST api's.
 */
package com.schwertz.carrentalservice.interfaces.web.rest.shared;
