
/**
 * Contains DTOs for presenting and transferring resources.
 */
package com.schwertz.carrentalservice.interfaces.web.rest.dtos;
