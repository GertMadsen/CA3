
/**
 * Contains configurations of the application.
 */
package com.schwertz.carrentalservice.configs;
