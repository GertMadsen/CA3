
/**
 * Contains class when combined models a business domain.
 */
package com.schwertz.carrentalservice.domain.model;
