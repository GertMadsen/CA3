
/**
 * Contains controllers that handles client's request/response for RESTful services.
 */
package com.schwertz.carrentalservice.interfaces.web.rest.controllers;
