
/**
 * Contains utilities that helps to run a business domain efficiently and is shared across all domains.
 */
package com.schwertz.carrentalservice.domain.shared;
